import reflex as rx

config = rx.Config(
    app_name="frontend",
    backend_port=8000,   # FastAPI backend
    frontend_port=3000,  # Reflex WebSocket port
    api_url="http://127.0.0.1:8000",
    deploy_url="http://127.0.0.1:3000",
    cors_allowed_origins=["*"],
)
